# MAD — Mian Associates & Developers

## Phase 1 complete
Next.js 14 App Router, TypeScript, Tailwind tokens, local Inter/Cormorant Garamond fonts, Framer Motion curtain reveal, GSAP cursor/scroll effects, Lenis and dynamically imported React Three Fiber architecture.

### Run
Requires Node 20.19+ (Node 22 recommended).
```sh
npm ci
npm run dev
# Production preview
npm run build
npm start
```

### Configuration
`config/site.ts` is the single source of truth for contact information, WhatsApp message, areas and services. Missing address, map URLs and email are `null`; socials are empty. Supply verified values before launch. No backend credentials are required for Phase 1.

### Components
- `experience.tsx`: header, hero, mobile menu, WhatsApp actions and native enquiry dialog.
- `building.tsx`: procedural conceptual residence, scroll rotation and pointer parallax. Not a real listing or portfolio claim.
- `effects.tsx`: monogram preloader, curtain, smooth scrolling, custom pointer and magnetic actions.
- `brand.tsx`: reusable SVG MAD monogram.
- `globals.css`: responsive tokens, effects and accessibility styles.

A small company/expertise bridge gives hero navigation meaningful destinations; full Phase 2 sections are not implemented. Enquire currently opens contact choices; it does not submit or store data. Supabase dependencies and environment template are prepared only. Database, API, authentication, RLS and admin arrive in Phase 5.

### Accessibility / performance
Touch devices do not receive custom cursors or magnetic effects. Reduced motion disables animated effects and renders an SVG architectural fallback instead of loading WebGL. The same fallback handles unavailable WebGL or a failed scene. Rendering pixel ratio is capped at 1.5. Contact controls have keyboard focus states, and the enquiry dialog uses native focus trapping / Escape dismissal.

### Validation
- `npm run typecheck`: passed.
- `npm run build`: passed.
- Playwright desktop (1440px), mobile (390px), menu/dialog and reduced-motion smoke checks: passed with no page errors.
- Run tests with the app on port 3000: `npx playwright install --with-deps chromium && node tests/smoke.mjs`.
- No Lighthouse score or real-device performance claim has been made.

### Launch blocker: dependency security
The requested Next.js 14 line is preserved, currently 14.2.35. The package audit reports a critical Next.js advisory and high findings in the dependency tree (`audit.json`). The suggested Next.js fix is a major-version upgrade. This is a working Phase 1 preview, **not a security-cleared production release**. Before public deployment, approve migration to a maintained/patched Next.js release, resolve remaining dependency advisories, and rerun compatibility/security tests. Do not silently run `npm audit fix --force`.

### Next phases
2. Full company, stats, CEO, team, services, areas.
3. Supabase listings and construction portfolio.
4. Trust, process, testimonials, FAQ and contact.
5. Validated inquiry API, SQL/RLS, Auth, Storage and admin.
6. SEO, accessibility/performance audit and deployment guide.
