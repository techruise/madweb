import type { Metadata } from 'next';
import './globals.css';
import { site } from '@/config/site';
export const metadata: Metadata = { title: 'MAD | Mian Associates & Developers', description: `${site.tagline} Property sale, purchase and construction in Lahore. Established ${site.established}.` };
export default function RootLayout({ children }: {children: React.ReactNode}) {
 return <html lang="en"><body>{children}</body></html>;
}
