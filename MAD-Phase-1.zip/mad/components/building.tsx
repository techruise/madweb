'use client';
import { Canvas, useFrame } from '@react-three/fiber';
import { useRef } from 'react';
import * as THREE from 'three';
function Block({pos, size, color='#747779', metal=.25}: {pos:[number,number,number]; size:[number,number,number]; color?:string; metal?:number}) {
 return <mesh position={pos} castShadow receiveShadow><boxGeometry args={size}/><meshStandardMaterial color={color} roughness={.65} metalness={metal}/></mesh>;
}
function Architecture() {
 const group = useRef<THREE.Group>(null);
 useFrame(({pointer,clock},delta) => {
  if (!group.current) return;
  const scroll = Math.min(window.scrollY / window.innerHeight, 1);
  group.current.rotation.y = THREE.MathUtils.damp(group.current.rotation.y, -.28 + pointer.x*.12 + scroll*.3, 3, delta);
  group.current.rotation.x = THREE.MathUtils.damp(group.current.rotation.x, pointer.y*.025, 3, delta);
  group.current.position.y = Math.sin(clock.elapsedTime*.35)*.025;
 });
 return <group ref={group}>
  <Block pos={[0,-.35,0]} size={[9,.22,6.6]} color="#363a3f"/>
  <Block pos={[0,-.19,0]} size={[8.1,.1,5.9]} color="#707375"/>
  {/* A conceptual residence, not a representation of a listed MAD project. */}
  {[0,1,2].map(f=><group key={f} position={[0,f*1.5,0]}>
    <Block pos={[0,.68,.2]} size={[6.4,1.4,3.9]} color="#242c32" metal={.65}/>
    <Block pos={[0,1.44,0]} size={[7.2,.2,4.8]} color="#9d9b93"/>
    <Block pos={[0,.04,2.3]} size={[7.2,.16,.4]} color="#999992"/>
    {[-3.1,-1.7,-.3,1.1,2.5,3.1].map((x,i)=><group key={i}>
      <Block pos={[x,.75,2.18]} size={[.065,1.3,.065]} color="#82827d"/>
      <Block pos={[x+.32,.71,2.02]} size={[.55,1.1,.025]} color={i%3===0?'#5f574b':'#34424a'} metal={.8}/>
    </group>)}
    <mesh position={[0,1.32,2.43]}><boxGeometry args={[6.85,.026,.028]}/><meshStandardMaterial color="#7A1626" emissive="#ba253f" emissiveIntensity={2}/></mesh>
    <Block pos={[0,.45,2.6]} size={[7,.035,.035]} color="#a4a4a0"/>
    {[-3.4,-1.7,0,1.7,3.4].map(x=><Block key={x} pos={[x,.25,2.6]} size={[.025,.4,.025]} color="#999b98"/>)}
   </group>)}
   <Block pos={[-2.58,2.16,2.28]} size={[1.03,4.55,.45]} color="#a4a19a"/>
   {Array.from({length:9},(_,i)=><Block key={i} pos={[-3.55+i*.115,2.16,2.62]} size={[.045,4.45,.16]} color="#666057"/>)}
   <Block pos={[1.45,4.81,-.4]} size={[3.6,.52,3.5]} color="#7c7d79"/>
   <Block pos={[1.45,5.14,-.4]} size={[4,.12,3.9]} color="#aaa79f"/>
   <Block pos={[3.3,2.3,-1.5]} size={[.3,4.6,1.2]} color="#8d8d86"/>
   {[0,1,2,3].map(i=><Block key={i} pos={[.9,-.05+i*.05,3+i*-.17]} size={[2.8,.08,.6]} color="#92918b"/>)}
   <Block pos={[-3.4,.13,2.9]} size={[1.1,.45,.7]} color="#44484a"/>
   {[-3.7,-3.35,-3].map(x=><mesh key={x} position={[x,.55,2.9]}><sphereGeometry args={[.3,8,8]}/><meshStandardMaterial color="#39443a"/></mesh>)}
   <Block pos={[3.4,.12,2.9]} size={[.65,.4,.65]} color="#44484a"/>
   <mesh position={[3.4,.67,2.9]}><sphereGeometry args={[.43,10,10]}/><meshStandardMaterial color="#3a473d"/></mesh>
 </group>;
}
export default function Building() {
 return <Canvas shadows dpr={[1,1.5]} camera={{position:[10,7.7,12.8],fov:37}} gl={{antialias:true,alpha:true,powerPreference:'low-power'}} onCreated={({camera})=>camera.lookAt(0,1.9,0)}>
 <ambientLight intensity={1.1}/><hemisphereLight args={['#bbc6d1','#303032',1.8]}/><directionalLight position={[2,10,6]} intensity={3} color="#e1d5be" castShadow shadow-mapSize={[1024,1024]}/><directionalLight position={[-5,3,-4]} intensity={2} color="#778796"/><pointLight position={[3,2,4]} color="#8e1830" intensity={12}/><Architecture/>
 </Canvas>;
}
