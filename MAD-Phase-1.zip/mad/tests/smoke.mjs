import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
const browser=await chromium.launch({args:['--no-sandbox']});
for (const mobile of [false,true]) {
 const page=await browser.newPage({viewport:mobile?{width:390,height:844}:{width:1440,height:1000},isMobile:mobile,hasTouch:mobile});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://localhost:3000');await page.waitForTimeout(3000);
 assert.equal(await page.locator('h1').count(),1);
 assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 if(mobile){await page.getByRole('button',{name:'Open menu'}).click();assert(await page.locator('#mobile-nav').isVisible());await page.getByRole('button',{name:'Close menu'}).click();await page.getByRole('button',{name:'Enquire',exact:true}).click();assert(await page.locator('dialog').isVisible());await page.keyboard.press('Escape');assert(!(await page.locator('dialog').isVisible()));}
 await page.screenshot({path:`/home/user/${mobile?'mobile':'desktop'}-check.png`,fullPage:true});
 assert.deepEqual(errors,[]);console.log(`${mobile?'Mobile':'Desktop'}: passed`);await page.close();
}
const reduced=await browser.newPage({reducedMotion:'reduce'});await reduced.goto('http://localhost:3000');await reduced.waitForTimeout(1000);assert.equal(await reduced.locator('canvas').count(),0);assert(await reduced.locator('.static-building').isVisible());console.log('Reduced-motion fallback: passed');await browser.close();
